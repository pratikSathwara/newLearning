$(window).scroll(function(){
    var scroll = $(window).scrollTop();
    if(scroll >= 100){
        $("header").addClass("sticky-top");
    } 
    else{
      $("header").removeClass("sticky-top");
  }
})
$('.common_section a').click(function (e) {
  e.preventDefault();
  $('#myTabContent .tab-pane').removeClass('show active');
  $('.nav-link').removeClass('active').attr("aria-selected", "false");
  var activeTab = $(this).attr('href');
  $('.nav-link[data-bs-target="' + activeTab + '"]').addClass('active').attr("aria-selected", "true");
  $(activeTab).addClass('show active');
  $("html, body").animate({scrollTop: $(activeTab).offset().top - 150  }, 500);
});
$(document).ready(function(){
  $('#home-slider').slick({
  autoplay: true,
  autoplaySpeed: 1200,
  arrows: false,
  dots: false,
  slidesToShow: 5,
  slideToScroll: 1,
  infinite: true,
  responsive: [
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          autoplaySpeed: 1500,
        },
      }
  ]
  });
  $('.slick-slider').slick({
    arrows: false,
    dots: false,
    slidesToShow: 3,
    slideToScroll: 1,
    infinite: false,
    responsive: [
        {
          breakpoint: 992,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 576,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        }
    ]
  });
  $('#new-left').click(function () {
    $('#slick-slider').slick('slickPrev');
  });
  $('#new-right').click(function () {
    $('#slick-slider').slick('slickNext');
  });
  $('#new-left1').click(function () {
    $('#slick-slider').slick('slickPrev');
  });
  $('#new-right1').click(function () {
    $('#slick-slider').slick('slickNext');
  });
  $(".ct-btn-scroll").on('click', function (event) {
    if (this.hash !== "") {
      event.preventDefault();
      var hash = this.hash;
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function () {
        window.location.hash = hash;
      });
    }
  });
});
$('.navbar-nav li.dropdown').click(function () { 
  $('.dropdown-menu').toggleClass('show');
});
$('.navbar-toggler').click(function () { 
    $('body').toggleClass('overflow-hidden');
    $('.dropdown-menu').removeClass('show');
});
/* Scroll Down Start  */
$(document).ready(function(){
  $(".ct-btn-scroll").on('click', function(event) {
    if (this.hash !== "") {
      event.preventDefault();
      var hash = this.hash;
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
        window.location.hash = hash;
      });
    } 
  });
});
/* Scroll Down end */
